-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: student_management_system
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `prefix` varchar(9) COLLATE ascii_bin DEFAULT NULL COMMENT 'The student''s prefix (if any)',
  `fName` varchar(20) COLLATE ascii_bin NOT NULL COMMENT 'The student''s first name',
  `mName` varchar(20) COLLATE ascii_bin NOT NULL COMMENT 'The student''s middle name',
  `lName` varchar(20) COLLATE ascii_bin NOT NULL COMMENT 'The student''s last name',
  `suffix` varchar(6) COLLATE ascii_bin DEFAULT NULL COMMENT 'The student''s suffix (if any)',
  `DOB` date NOT NULL COMMENT 'The student''s date of birth',
  `gender` char(1) COLLATE ascii_bin NOT NULL COMMENT 'The student''s gender',
  `ethnicity` varchar(41) COLLATE ascii_bin NOT NULL COMMENT 'The student''s ethnicity',
  `email` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'The student''s email',
  `uniEmail` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'The student''s university email; characters left of email’s ‘@’ symbol + “@mascot.uni.edu”',
  `password` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'The student''s password; ',
  `username` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'The student''s username; characters left of email’s ‘@’ symbol',
  `classification` varchar(8) COLLATE ascii_bin NOT NULL COMMENT 'The student''s classification/grade level',
  `college` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college the student''s in; foreign key to College table',
  `stuID` tinyint(1) NOT NULL AUTO_INCREMENT COMMENT 'The student''s ID; Auto-incremented; Primary key',
  `degreeName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The name of the student''s degree; Derived from Degree table',
  `degreeType` varchar(20) COLLATE ascii_bin DEFAULT NULL COMMENT 'The type of degree the student has/is pursuing; Derived from Degree table',
  `address` varchar(45) COLLATE ascii_bin NOT NULL COMMENT 'The student''s home address',
  `charges` decimal(7,2) NOT NULL COMMENT 'The charges the student has to pay (if any)',
  `telNo` varchar(14) COLLATE ascii_bin NOT NULL COMMENT 'The student''s telephone number',
  PRIMARY KEY (`stuID`),
  UNIQUE KEY `stuID_UNIQUE` (`stuID`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `uniEmail_UNIQUE` (`uniEmail`),
  UNIQUE KEY `telNo_UNIQUE` (`telNo`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `college` (`college`),
  KEY `degreeName` (`degreeName`),
  KEY `degreeType` (`degreeType`),
  CONSTRAINT `college` FOREIGN KEY (`college`) REFERENCES `college` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `degreeName` FOREIGN KEY (`degreeName`) REFERENCES `degree` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `degreeType` FOREIGN KEY (`degreeType`) REFERENCES `degree` (`type`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=ascii COLLATE=ascii_bin COMMENT='The students of the management system. Users who login as students can view their respective college''s info, enroll in courses, view their personal info, etc. Admins can update and delete a student''s info.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('null','Brandon','Marshall','Jones','null','1998-02-06','M','Black or African American','bjones@gmail.com','bjones@mascot.uni.edu','bvdkfbwbfwo','bjones','Freshman','Witchcraft',1,'Metal Conversion','B.S.','1357 Hope St',0.00,'555-158-1368'),('null','Tyson','Darius','Regal','II','1997-02-25','M','White','tregal@hotmail.com','tregal@mascot.uni.edu','Royalty','tregal','Freshman','Witchcraft',2,'Metal Conversion','A.S.','1638 Muholland Rd',0.00,'555-273-5832'),('null','Clare','Marissa','Shields','null','1998-06-13','F','White','cshields@gmail.com','cshields@mascot.uni.edu','Shield','cshields','Alumnus','Witchcraft',3,'Metal Conversion','B.S.','1736 Divine Rd',0.00,'555-162-9625'),('Ms.','Osiris','Emilia','Jackson','null','1990-06-16','F','Black or African American','ojackson@hotmail.com','ojackson@mascot.uni.edu','Lake','ojackson','Sophmore','Science & Technology',4,'Computer Science','B.S.','1573 Cross Rd',0.00,'555-738-3579'),('Mrs.','Clarissa','Diana','Stewart','null','1988-05-05','F','White','cstewart@hotmail.net','cstewart@mascot.uni.edu','viofo87f','cstewart','Sophmore','Science & Technology',5,'Computer Science','B.S.','2746 Highland Ln',0.00,'555-697-3689'),('null','Gina','Winona','Rodriguez','null','1990-02-14','F','Hispanic or Latino','grodriguez@aol.com','grodriguez@mascot.uni.edu','gina','grodriguez','Freshman','Science & Technology',6,'Computer Science','B.S.','2683 Jive Rd',0.00,'555-158-3574'),('Mr.','Xavier','Quincy','Adams','Jr.','1997-02-15','M','Black or African American','xadams@hotmail.com','xadams@mascot.uni.edu','Quintet','xadams','Freshman','Daemons',7,'Soul Manipulation','A.S.','4725 Switch Ln',0.00,'555-689-2583'),('null','Curtis','Lycan','Jackson','V','1987-06-12','M','Black or African American','cjackson@gmail.com','cjackson@mascot.uni.edu','50cent','cjackson','Freshman','Daemons',8,'Soul Manipulation','B.S.','3647 Verona Dr',0.00,'555-972-4647'),('null','Cletus','Leonard','Hillman','null','1995-06-16','M','White','chillman@gmail.net','chillman@mascot.uni.edu','cletus','chillman','Junior','Daemons',9,'Soul Manipulation','B.S.','2635 ',0.00,'555-368-2683'),('Miss','Ashley','Kylie','Watson','null','1998-02-04','F','White','awatson@gmail.com','awatson@mascot.uni.edu','fghhgeh','awatson','Sophmore','Hard Knocks',10,'Martial Arts','B.S.','5724 Serpentine Rd',100.00,'555-827-2536'),('Ms.','Veronica','Eliza','Burgundy','null','1989-07-15','F','White','vburgundy@aol.net','vburgundy@mascot.uni.edu','rojo','vburgundy','Freshman','Hard Knocks',11,'Martial Arts','B.S.','9246 Burgundy Ln',450.00,'555-172-5272'),('null','Gerald','Timothy','Base','III','1997-02-24','M','White','gbase@gmail.com','gbase@mascot.uni.edu','percussion','gbase','Alumnus','Hard Knocks',12,'Martial Arts','M.S.','4724 Music Rd',0.00,'555-614-7246');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-21 16:06:24
