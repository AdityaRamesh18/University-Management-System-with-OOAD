-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: student_management_system
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `college`
--

DROP TABLE IF EXISTS `college`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `college` (
  `name` varchar(30) COLLATE ascii_bin NOT NULL DEFAULT 'College' COMMENT 'The college''s name',
  `address` varchar(30) COLLATE ascii_bin NOT NULL DEFAULT '9999 Some St' COMMENT 'The college''s address',
  `email` varchar(30) COLLATE ascii_bin NOT NULL DEFAULT 'someemail@site.com' COMMENT 'The college''s email',
  `officeNo` varchar(6) COLLATE ascii_bin NOT NULL DEFAULT 'A-100' COMMENT 'The college''s office number',
  `deanPrefix` varchar(9) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s dean''s prefix (if any)',
  `dean_fName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s dean''s first name',
  `dean_mName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s dean''s middle name',
  `dean_lName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s dean''s last name',
  `deanSuffix` varchar(6) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s dean''s suffix (if any)',
  `assocDean_prefix` varchar(9) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s associate dean''s prefix (if any)',
  `assocDean_fName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s associate dean''s first name',
  `assocDean_mName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s associate dean''s middle name',
  `assocDean_lName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s associate dean''s last name',
  `assocDean_suffix` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s associate dean''s suffix (if any)',
  `asstDean_prefix` varchar(9) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s assistant dean''s prefix (if any)',
  `asstDean_fName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s assistant dean''s first name',
  `asstDean_mName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s assistant dean''s middle name',
  `asstDean_lName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s assistant dean''s last name',
  `asstDean_suffix` varchar(6) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college''s assistant dean''s suffix (if any)',
  `telNo` varchar(14) COLLATE ascii_bin NOT NULL DEFAULT '999-999-9999' COMMENT 'The college''s telephone number',
  `faxNo` varchar(14) COLLATE ascii_bin NOT NULL DEFAULT '999-999-9999',
  `advisingNo` varchar(6) COLLATE ascii_bin NOT NULL DEFAULT 'A-100' COMMENT 'The college''s advising office''s office number',
  `advisingEmail` varchar(30) COLLATE ascii_bin NOT NULL DEFAULT 'advisingemail@college.edu' COMMENT 'The college''s advising office''s email',
  PRIMARY KEY (`name`),
  UNIQUE KEY `advisingEmail_UNIQUE` (`advisingEmail`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `deanPrefix` (`deanPrefix`),
  KEY `deanSuffix` (`deanSuffix`),
  KEY `assocDean_prefix` (`assocDean_prefix`),
  KEY `assocDean_suffix` (`assocDean_suffix`),
  KEY `asstDean_prefix` (`asstDean_prefix`),
  KEY `asstDean_suffix` (`asstDean_suffix`),
  KEY `college4` (`name`) /*!80000 INVISIBLE */,
  KEY `college5` (`name`),
  KEY `dean_fName` (`dean_fName`),
  KEY `dean_mName` (`dean_mName`),
  KEY `dean_lName` (`dean_lName`),
  KEY `assocDean_fName` (`assocDean_fName`),
  KEY `assocDean_mName` (`assocDean_mName`),
  KEY `assocDean_lName` (`assocDean_lName`),
  KEY `asstDean_fName` (`asstDean_fName`),
  KEY `asstDean_mName` (`asstDean_mName`),
  KEY `asstDean_lName` (`asstDean_lName`),
  CONSTRAINT `assocDean_fName` FOREIGN KEY (`assocDean_fName`) REFERENCES `staff` (`fName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `assocDean_lName` FOREIGN KEY (`assocDean_lName`) REFERENCES `staff` (`lName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `assocDean_mName` FOREIGN KEY (`assocDean_mName`) REFERENCES `staff` (`mName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `assocDean_prefix` FOREIGN KEY (`assocDean_prefix`) REFERENCES `staff` (`prefix`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `assocDean_suffix` FOREIGN KEY (`assocDean_suffix`) REFERENCES `staff` (`suffix`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `asstDean_fName` FOREIGN KEY (`asstDean_fName`) REFERENCES `staff` (`fName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `asstDean_lName` FOREIGN KEY (`asstDean_lName`) REFERENCES `staff` (`lName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `asstDean_mName` FOREIGN KEY (`asstDean_mName`) REFERENCES `staff` (`mName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `asstDean_prefix` FOREIGN KEY (`asstDean_prefix`) REFERENCES `staff` (`prefix`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `asstDean_suffix` FOREIGN KEY (`asstDean_suffix`) REFERENCES `staff` (`suffix`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `dean_fName` FOREIGN KEY (`dean_fName`) REFERENCES `staff` (`fName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `dean_lName` FOREIGN KEY (`dean_lName`) REFERENCES `staff` (`lName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `dean_mName` FOREIGN KEY (`dean_mName`) REFERENCES `staff` (`mName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `deanPrefix` FOREIGN KEY (`deanPrefix`) REFERENCES `staff` (`prefix`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `deanSuffix` FOREIGN KEY (`deanSuffix`) REFERENCES `staff` (`suffix`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `college`
--

LOCK TABLES `college` WRITE;
/*!40000 ALTER TABLE `college` DISABLE KEYS */;
INSERT INTO `college` VALUES ('Daemons','6666 Dark Rd','daemons@aol.com','A-345 ',NULL,'Angel','Power','Grove',NULL,NULL,'Raul','Zavata','Menendez','II',NULL,'Gerald','World',NULL,'II','555-678-4545','555-173-8346','A-349 ','daemonsexorcism@aol.com'),('Hard Knocks','2468 Tough St','hk@gmail.hkl','S-768 ',NULL,'Drago','Darius','Snake',NULL,NULL,'Harold','Max','Lee',NULL,NULL,'Cody','Harold',NULL,'II','555-844-3333','555-246-7518','S-770 ','hkhelp@gmail.hkl'),('Science & Technology','7777 Facts St','cst@college.com','S-123 ',NULL,'Reed','Joseph','Richards','Sr.',NULL,'Cornell','West',NULL,NULL,NULL,'Tony','William','Stark',NULL,'555-789-1011','555-426-3217','S-1234','csthelp@college.com'),('Witchcraft','9999 Heavenly Rd','witchcraft@gmail.net','N-123 ','Dr.','Victor','Von','Doom',NULL,NULL,'Leon','Edgar','Kennedy',NULL,NULL,'Aliza','Merith','Pope',NULL,'555-123-4567','555-111-2333','N-125 ','witchcrafthelp@gmail.net');
/*!40000 ALTER TABLE `college` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-21 16:06:23
