-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: student_management_system
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `prefix` varchar(9) COLLATE ascii_bin DEFAULT NULL COMMENT 'The staff member''s prefix (if any)',
  `fName` varchar(20) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s first name',
  `mName` varchar(20) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s last name',
  `lName` varchar(20) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s last name',
  `suffix` varchar(6) COLLATE ascii_bin DEFAULT NULL COMMENT 'The staff member''s suffix (if any)',
  `DOB` date NOT NULL COMMENT 'The staff member''s birth date',
  `gender` char(1) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s gender',
  `ethnicity` varchar(42) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s ethnicity',
  `email` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s email',
  `uniEmail` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s university email; characters left of email’s ‘@’ symbol + “@mascot.uni.edu”',
  `password` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s password',
  `username` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s username; characters left of email’s ‘@’ symbol',
  `position` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s position/role',
  `staffNo` tinyint(1) NOT NULL AUTO_INCREMENT COMMENT 'The staff member''s ID number',
  `department` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The department the staff member works in; foreign key',
  `college` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college the staff member works in; foreign key',
  `officeNo` varchar(6) COLLATE ascii_bin DEFAULT NULL COMMENT 'The staff member''s office number (if any)',
  `telNo` varchar(14) COLLATE ascii_bin NOT NULL COMMENT 'The staff member''s telephone number',
  `officeDays` varchar(7) COLLATE ascii_bin DEFAULT NULL COMMENT 'The days on which the staff member''s office is open',
  `office_start_time` time DEFAULT NULL COMMENT 'The time at which the staff member''s office opens',
  `office_end_time` time DEFAULT NULL COMMENT 'The time at which the staff member''s office closes',
  `salary` decimal(7,2) NOT NULL,
  PRIMARY KEY (`staffNo`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `uniEmail_UNIQUE` (`uniEmail`),
  UNIQUE KEY `telNo_UNIQUE` (`telNo`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `department` (`department`),
  KEY `college2` (`college`) /*!80000 INVISIBLE */,
  KEY `fName` (`fName`) /*!80000 INVISIBLE */,
  KEY `lName` (`lName`) /*!80000 INVISIBLE */,
  KEY `mName` (`mName`) /*!80000 INVISIBLE */,
  KEY `prefix` (`prefix`) /*!80000 INVISIBLE */,
  KEY `suffix` (`suffix`) /*!80000 INVISIBLE */,
  KEY `DOB` (`DOB`) /*!80000 INVISIBLE */,
  KEY `gender` (`gender`) /*!80000 INVISIBLE */,
  KEY `ethnicity` (`ethnicity`) /*!80000 INVISIBLE */,
  KEY `email` (`email`) /*!80000 INVISIBLE */,
  KEY `uniEmail` (`uniEmail`) /*!80000 INVISIBLE */,
  KEY `password` (`password`) /*!80000 INVISIBLE */,
  KEY `username` (`username`) /*!80000 INVISIBLE */,
  KEY `position` (`position`) /*!80000 INVISIBLE */,
  KEY `staffNo` (`staffNo`) /*!80000 INVISIBLE */,
  KEY `telNo` (`telNo`) /*!80000 INVISIBLE */,
  KEY `officeDays` (`officeDays`) /*!80000 INVISIBLE */,
  KEY `office_start_time` (`office_start_time`) /*!80000 INVISIBLE */,
  KEY `office_end_time` (`office_end_time`),
  KEY `salary` (`salary`),
  KEY `officeNo` (`officeNo`),
  KEY `deanPrefix` (`prefix`) /*!80000 INVISIBLE */,
  KEY `dean_first_name` (`fName`) /*!80000 INVISIBLE */,
  KEY `dean_middle_name` (`mName`) /*!80000 INVISIBLE */,
  KEY `dean_last_name` (`lName`) /*!80000 INVISIBLE */,
  KEY `deanSuffix` (`suffix`) /*!80000 INVISIBLE */,
  KEY `assocDean_prefix` (`prefix`) /*!80000 INVISIBLE */,
  KEY `assocDean_first_name` (`fName`) /*!80000 INVISIBLE */,
  KEY `assocDean_middle_name` (`mName`) /*!80000 INVISIBLE */,
  KEY `assocDean_last_name` (`lName`) /*!80000 INVISIBLE */,
  KEY `assocDean_suffix` (`suffix`) /*!80000 INVISIBLE */,
  KEY `asstDean_prefix` (`prefix`) /*!80000 INVISIBLE */,
  KEY `asstDean_first_name` (`fName`) /*!80000 INVISIBLE */,
  KEY `asstDean_middle_name` (`mName`) /*!80000 INVISIBLE */,
  KEY `asstDean_last_name` (`lName`) /*!80000 INVISIBLE */,
  KEY `asstDean_suffix` (`suffix`),
  KEY `instructor_first_name` (`fName`) /*!80000 INVISIBLE */,
  KEY `instructor_last_name` (`lName`),
  KEY `deptChair_prefix` (`prefix`) /*!80000 INVISIBLE */,
  KEY `deptChair_first_name` (`fName`) /*!80000 INVISIBLE */,
  KEY `deptChair_middle_name` (`mName`) /*!80000 INVISIBLE */,
  KEY `deptChair_last_name` (`lName`) /*!80000 INVISIBLE */,
  KEY `deptChair_suffix` (`suffix`) /*!80000 INVISIBLE */,
  KEY `firstAsstChair_prefix` (`prefix`) /*!80000 INVISIBLE */,
  KEY `firstAsstChair_first_name` (`fName`),
  KEY `firstAsstChair_middle_name` (`mName`) /*!80000 INVISIBLE */,
  KEY `firstAsstChair_last_name` (`lName`) /*!80000 INVISIBLE */,
  KEY `firstAsstChair_suffix` (`suffix`) /*!80000 INVISIBLE */,
  KEY `secAsstChair_prefix` (`prefix`) /*!80000 INVISIBLE */,
  KEY `secAsstChair_first_name` (`fName`) /*!80000 INVISIBLE */,
  KEY `secAsstChair_middle_name` (`mName`) /*!80000 INVISIBLE */,
  KEY `secAsstChair_last_name` (`lName`) /*!80000 INVISIBLE */,
  KEY `secAsstChair_suffix` (`suffix`),
  CONSTRAINT `college2` FOREIGN KEY (`college`) REFERENCES `college` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `department` FOREIGN KEY (`department`) REFERENCES `department` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES ('Dr.','Victor','Von','Doom','null','1981-02-16','M','White','doom@hotmail.com','doom@mascot.uni.edu','a394fke','doom','Dean',27,'Alchemy','Witchcraft','A-300 ','555-162-3483','Mon/Wed','15:00:00','16:00:00',70000.00),('null','Alexander','Darius','Great','null','1982-08-05','M','American Indian or Alaska Native','dgreat@gmail.com','dgreat@mascot.uni.edu','dlve2iv','dgreat','Assistant Dean',29,'Alchemy','Witchcraft','A-2534','555-748-4326','Tu/Th','16:00:00','17:00:00',70000.00),('null','Quavious','Quincy','Quaker','null','1992-12-29','M','Black or African American','datway@hotmail.net','datway@mascot.uni.edu','dlwiebckalehc','datway','Associate Dean',30,'Alchemy','Witchcraft','S-1098','555-096-1368','Th','14:00:00','15:00:00',70000.00),('Professor','Leon','Edgar','Kennedy','III','1988-07-24','M','White','residentevil@aol.net','residentevil@mascot.uni.edu','Lmfsrocq45','residentevil','Associate Dean',31,'Alchemy','Witchcraft','S-248 ','555-723-7502','Tu','11:00:00','12:00:00',70000.00),('null','Rita','Jane','Repulsa','null','1976-11-15','F','White','rrepulsa@hotmail.com','rrepulsa@mascot.uni.edu','moon','rrepulsa','Dean',35,'Necromancy','Daemons','N-228 ','555-145-1234','Tu/Th','10:00:00','11:00:00',75000.00),('Mr.','Gerald','World','Jones','II','1989-01-01','M','Asian','gjones@hotmail.gov','gjones@mascot.uni.edu','newworldorder','gjones','Assistant Dean',36,'Necromancy','Daemons','S-184 ','555-189-2492','Mon/Wed','16:00:00','17:00:00',70000.00),('Professor','Raul','Zavata','Menendez','II','1992-07-26','M','Hispanic or Latino','rmenendez@aol.com','rmenendez@mascot.uni.edu','dsnfewibfedxs','rmenendez','Associate Dean',37,'Necromancy','Daemons','S-1103','555-761-1823','Wed','14:00:00','15:00:00',70000.00),('null','Xavier','Marauder','Jones','IV','1985-04-15','M','Native Hawaiian or Other Pacific Islander','xjones@gmail.com','xjones@mascot.uni.edu','ajcneo53q1','xjones','Adjunct Professor',40,'Fisticuffs','Hard Knocks','N-147 ','555-196-2505','Mon','13:00:00','14:00:00',65000.00),('null','Drago','Darius','Snake','null','1986-06-16','M','Hispanic or Latino','dsnake@gmail.com','dsnake@mascot.uni.edu','Wzhrmcueal','dsnake','Dean',42,'Fisticuffs','Hard Knocks','N-1300','555-549-2941','Tu/Th','13:30:00','14:30:00',75000.00),('null','Cody','Harold','Jones','II','1987-08-08','M','White','cjones@hotmail.org','cjones@mascot.uni.edu','Nadgrwd','cjones','Assistant Dean',44,'Fisticuffs','Hard Knocks','S-275 ','555-180-4369','Mon/Wed','12:00:00','13:00:00',70000.00),('null','Harold','Max','Lee','null','1988-07-15','M','White','hlee@aol.net','hlee@mascot.uni.edu','Nkdorhcnsla','hlee','Associate Dean',45,'Fisticuffs','Hard Knocks','A-1085','555-814-8622','Fri','15:30:00','16:30:00',70000.00),('Mr.','Reed','Joseph','Richards','Sr.','1983-02-27','M','White','rrichards@gmail.com','rrichards@mascot.uni.edu','Fantastic4','rrichards','Dean',46,'Computer Science','Science & Technology','A-912 ','555-169-4586','Tu/Th','17:00:00','18:00:00',70000.00),('Mr.','Tony','William','Stark','null','1980-04-03','M','White','tstark@aol.net','tstark@mascot.uni.edu','starkindustries','tstark','Assistant Dean',47,'Computer Science','Science & Technology','N-1000','555-592-4936','Mon/Wed','16:30:00','17:30:00',70000.00),('Mr.','Cornell','West','Jackson','V','1987-04-12','M','Native Hawaiian or Other Pacific Islander','cjackson@hotmail.net','cjackson@mascot.uni.edu','foeucjsqourfkx','cjackson','Associate Dean',48,'Computer Science','Science & Technology','S-628 ','555-581-3491','Wed','14:30:00','15:30:00',70000.00),('Miss','Aliza','Merith','Pope','null','1978-02-17','F','Asian','apope@hotmail.com','apope@mascot.uni.edu','akirjxjbf','apope','Assistant Dean',49,'Alchemy','Witchcraft','A-360 ','555-193-7938','Mon/Wed','13:00:00','14:00:00',70000.00),('Mr.','Jeffrey','Marco','Don','III','1988-03-26','M','Black or African American','jdon@hotmail.com','jdon@mascot.uni.edu','adkgoeucngr','jdon','Department Chair',50,'Alchemy','Witchcraft','A-573 ','555-184-2385','Mon/Wed','14:00:00','15:00:00',60000.00),('Mr.','Marco','Henry','Aguilar','null','1984-04-16','M','Hispanic or Latino','maguilar@aol.com','maguilar@mascot.uni.edu','adjvbiwfbiwbf','maguilar','First Department Chair',52,'Alchemy','Witchcraft','N-289 ','555-159-3495','Mon/Wed','12:00:00','13:00:00',65000.00),('null','Sergio','Savant','Savage','null','1988-09-15','M','American Indian or Alaska Native','ssavage@hotmail.com','ssavage@mascot.uni.edu','Savage','ssavage','Second Department Chair',53,'Alchemy','Witchcraft','A-583 ','555-690-1596','Th','16:00:00','17:00:00',65000.00),('null','King','Fire','Crimson','V','1986-08-04','M','White','kcrimson@gmail.com','kcrimson@mascot.uni.edu','Crimson','kcrimson','Department Chair',54,'Computer Science','Science & Technology','S-285 ','555-289-1594','Mon/Wed','14:30:00','15:30:00',60000.00),('null','Tamina','Zeno','Zero','null','1988-03-18','F','Asian','tzero@gmail.com','tzero@mascot.uni.edu','Zero','tzero','First Department Chair',55,'Computer Science','Science & Technology','N-163 ','555-382-4852','null','12:30:00','13:30:00',65000.00),('null','Xerion','Seraph','Jones','null','1979-02-07','M','Native Hawaiian or Other Pacific Islander','seraph@hotmail.com','seraph@mascot.uni.edu','Seraph','seraph','Second Department Chair',57,'Computer Science','Science & Technology','A-283 ','555-195-0362','Tu/Th','12:30:00','13:30:00',65000.00),('null','Angela','Carol','Marcel','null','1982-06-08','F','White','amarcel@gmail.com','amarcel@mascot.uni.edu','calriqpk3','amarcel','Department Chair',58,'Fisticuffs','Hard Knocks','A-104 ','555-192-4824','null','12:00:00','13:00:00',65000.00),('null','Robin','Winans','Wave','null','1988-05-08','F','Black or African American','rwave@hotmail.com','rwave@mascot.uni.edu','D259ckake','rwave','First Department Chair',59,'Fisticuffs','Hard Knocks','N-173 ','555-828-2733','Mon/Wed','14:30:00','15:30:00',65000.00),('null','Serena','Moonlight','Dior','null','1987-03-15','F','Black or African American','sdior@aol.com','sdior@mascot.uni.edu','Weovkcmfle2','sdior','Second Department Chair',60,'Fisticuffs','Hard Knocks','N-1100','555-293-6842','Fri','15:30:00','16:30:00',65000.00),('null','Angel','Power','Grove','null','1979-03-01','F','White','prangers@gmail.com','prangers@mascot.uni.edu','Zordon','prangers','Dean',61,'Necromancy','Daemons','S-127 ','555-184-3892','Mon/Wed','15:30:00','16:30:00',70000.00),('Mr.','Chris','Jameson','Masterson','II','1986-08-23','M','White','cmasterson@aol.net','cmasterson@mascot.uni.edu','master','cmasterson','First Department Chair',62,'Necromancy','Daemons','A-1183','555-293-6835','Mon/Wed','14:00:00','15:00:00',65000.00),('null','James','Winans','Adams','II','1988-04-16','M','White','jadams@gmail.com','jadams@mascot.uni.edu','cndowpd;akw','jadams','Second Department Chair',63,'Necromancy','Daemons','N-1922','555-182-4693','Tu','12:30:00','13:30:00',65000.00),('Mr.','Peter','Rabbit','Cottontail','II','1985-06-14','M','White','pcottontail@gmail.com','pcottontail@mascot.uni.edu','rabid','pcottontail','Adjunct Professor',79,'Necromancy','Daemons','S-836 ','555-938-2573','Mon/Wed','12:30:00','13:30:00',55000.00),('null','Roger','Hare','Deion','null','1983-11-08','M','Hispanic or Latino','rdeion@aol.com','rdeion@mascot.uni.edu','hare','rdeion','Assistant Professor',80,'Necromancy','Daemons','N-247 ','555-618-2846','Fri','14:30:00','15:30:00',55000.00),('Professor','Bobby','Boxer','Balboa','III','1979-07-13','M','Asian','boxer@gmail.com','boxer@mascot.uni.edu','southpaw','boxer','Adjunct Professor',83,'Fisticuffs','Hard Knocks','S-427 ','555-037-2846','Tu/Th','16:00:00','17:00:00',55000.00),('Mrs.','Tamera','Libra','Wright','null','1982-07-17','F','Black or African American','twright@hotmail.com','twright@mascot.uni.edu','Libra','twright','Assistant Professor',85,'Alchemy','Witchcraft','S-305 ','555-274-1673','Tu/Th','14:30:00','15:30:00',54000.00),('Ms.','Marissa','Saraya','Venice','null','1982-02-04','F','Hispanic or Latino','mvenice@aol.com','mvenice@mascot.uni.edu','Italy','mvenice','Adjunct Professor',87,'Alchemy','Witchcraft','A-974 ','555-927-2174','Mon/Wed','14:00:00','15:00:00',56000.00),('null','Yelena','Faris','Plains','null','1987-05-08','F','White','yplains@hotmail.com','yplains@mascot.uni.edu','grass','yplains','Associate Professor',90,'Computer Science','Science & Technology','N-1874','555-037-1735','Fri','12:00:00','13:00:00',55000.00),('Mr.','Byron','Max','Jones','null','1988-07-03','M','Black or African American','bjones@gmail.com','bjones@mascot.uni.edu','19*dngwog','bjones','Assistant Professor',91,'Computer Science','Science & Technology','S-483 ','555-802-5827','Mon','15:00:00','16:00:00',55000.00),('Professor','Marcus','Gerald','Bones','null','1981-06-16','M','Black or African American','mbones@hotmail.com','mbones@mascot.uni.edu','Bones','mbones','Adjunct Professor',92,'Computer Science','Science & Technology','N-1015','555-716-1473','Tu/Th','13:00:00','14:00:00',58000.00),('null','Adam','Jerold','Veneer','null','1983-07-26','M','White','aveneer@gmail.com','aveneer@mascot.uni.edu','sueveneer','aveneer','Assistant Professor',93,'Necromancy','Daemons','S-983 ','555-789-1725','Mon/Wed','14:00:00','15:00:00',54000.00),('null','Bryan','Grimy','McCullen','null','1978-01-03','M','White','bmccullen@hotmail.com','bmccullen@mascot.uni.edu','grimy','bmccullen','Associate Professor',94,'Fisticuffs','Hard Knocks','A-279 ','555-037-1725','Tu/Th','13:00:00','14:00:00',55000.00),('Mr.','Rick','Fare','Jackson','II','1984-06-09','M','White','rjackson@gmail.com','rjackson@mascot.uni.edu','feral','rjackson','Adjunct Professor',95,'Fisticuffs','Hard Knocks','A-1355','555-917-2736','Fri','13:30:00','14:30:00',57000.00),('null','Mason','Wick','Maroon','null','1986-11-06','M','White','mmaroon@aol.com','mmaroon@mascot.uni.edu','freemason','mmaroon','Adjunct Professor',96,'Alchemy','Witchcraft','N-735 ','555-390-1847','Mon/Wed','15:00:00','16:00:00',58000.00),('Mr.','Herald','Iona','Whistleblower','IV','1984-02-11','M','White','whistleblower@gmail.com','whistleblower@mascot.uni.edu','blowthewhistle','whistleblower','Department Chair',97,'Necromancy','Daemons','A-456 ','555-928-4725','Tu/Th','12:00:00','01:00:00',70000.00);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-21 16:06:25
