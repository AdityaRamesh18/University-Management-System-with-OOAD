-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: student_management_system
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course` (
  `name` varchar(20) COLLATE ascii_bin NOT NULL COMMENT 'The course''s name',
  `courseNo` smallint NOT NULL COMMENT 'The course''s number',
  `description` varchar(40) COLLATE ascii_bin NOT NULL COMMENT 'The class''s description',
  `college` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The college the course is under',
  `department` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The department the course is under',
  `type` varchar(17) COLLATE ascii_bin NOT NULL COMMENT 'The type of course that''s offered',
  `mode` varchar(12) COLLATE ascii_bin NOT NULL COMMENT 'The way the course is delivered',
  `instructor_prefix` varchar(9) COLLATE ascii_bin DEFAULT NULL,
  `instructor_fName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The instructor''s first name',
  `instructor_mName` varchar(20) COLLATE ascii_bin DEFAULT NULL,
  `instructor_lName` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The instructor''s last name',
  `instructor_suffix` varchar(6) COLLATE ascii_bin DEFAULT NULL,
  `numStudents` tinyint NOT NULL DEFAULT '0' COMMENT 'The number of students enrolled in the course',
  `maxStudents` tinyint NOT NULL DEFAULT '0',
  `credits` tinyint NOT NULL DEFAULT '1' COMMENT 'The number of credits a course offers',
  `startTime` time NOT NULL COMMENT 'The time the course starts',
  `endTime` time NOT NULL COMMENT 'The time the course ends',
  `location` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'Where the course is being taught',
  `classroomNo` varchar(6) COLLATE ascii_bin NOT NULL COMMENT 'The course''s classroom''s number',
  `courseDays` varchar(7) COLLATE ascii_bin NOT NULL COMMENT 'The days on which the course is taught',
  `crn` smallint NOT NULL COMMENT 'The course reference number',
  PRIMARY KEY (`crn`),
  UNIQUE KEY `coursecol_UNIQUE` (`crn`),
  KEY `department4` (`department`),
  KEY `college5` (`college`),
  KEY `instructor_first_name` (`instructor_fName`),
  KEY `instructor_last_name` (`instructor_lName`),
  KEY `instructor_middle_name` (`instructor_mName`),
  KEY `instructor_prefix` (`instructor_prefix`),
  KEY `instructor_suffix` (`instructor_suffix`),
  CONSTRAINT `college5` FOREIGN KEY (`college`) REFERENCES `college` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `department4` FOREIGN KEY (`department`) REFERENCES `department` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `instructor_first_name` FOREIGN KEY (`instructor_fName`) REFERENCES `staff` (`fName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `instructor_last_name` FOREIGN KEY (`instructor_lName`) REFERENCES `staff` (`lName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `instructor_middle_name` FOREIGN KEY (`instructor_mName`) REFERENCES `staff` (`mName`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `instructor_prefix` FOREIGN KEY (`instructor_prefix`) REFERENCES `staff` (`prefix`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `instructor_suffix` FOREIGN KEY (`instructor_suffix`) REFERENCES `staff` (`suffix`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES ('ALC 1400',1100,'Elemental Magic','Witchcraft','Alchemy','Lecture','Face-to-Face','Mrs.','Tamera','Libra','Wright','null',0,10,1,'13:00:00','14:15:00','1836 Magic St','S-146 ','Tu/Th',10000),('CS 1411',1101,'Data Structures & Algorithms (C++)','Science & Technology','Computer Science','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,30,4,'12:00:00','13:15:00','4567 Tech Ln','N-462 ','Mon/Wed',10001),('CS 1420',1102,'Intro to Computer Science (Python)','Science & Technology','Computer Science','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,30,4,'12:30:00','13:45:00','4567 Tech Ln','S-264 ','Mon/Wed',10002),('CS 1430',1105,'Intro to Computer Science (Java)','Science & Technology','Computer Science','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,30,4,'12:30:00','13:45:00','4567 Tech Ln','S-350 ','Mon/Wed',10005),('CS 1421',1100,'Data Structures & Algorithms (Python)','Science & Technology','Computer Science','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,30,4,'13:15:00','14:30:00','4567 Tech Ln','A-468 ','Tu/Th',10007),('CS 1431',1106,'Data Structures & Algorithms (Java)','Science & Technology','Computer Science','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,30,4,'13:00:00','14:15:00','4567 Tech Ln','A-700 ','Tu/Th',10009),('ALC 1300',1107,'Metal Conversion','Witchcraft','Alchemy','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,25,3,'13:00:00','14:15:00','1836 Magic St','A-290 ','Mon/Wed',10010),('ALC 1300',1107,'Metal Conversion','Witchcraft','Alchemy','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,25,3,'13:00:00','14:15:00','1836 Magic St','A-357 ','Tu/Th',10011),('ALC 1400',1108,'Elemental Magic','Witchcraft','Alchemy','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,40,4,'12:00:00','13:15:00','1836 Magic St','N-1300','Mon/Wed',10012),('HDNK 1400',1111,'Hand-to-Hand Combat','Hard Knocks','Fisticuffs','Lecture','Face-to-Face','Professor','Bobby','Boxer','Balboa','III',1,40,4,'14:00:00','15:15:00','1234 Tough St','N-600 ','Mon/Wed',10023),('DMN 1400',1100,'Necromancy','Daemons','Necromancy','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,10,1,'14:00:00','15:15:00','1836 Magic St','N-900 ','Mon/Wed',10024),('DMN 1400',1100,'Necromancy','Daemons','Necromancy','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,10,1,'13:00:00','14:15:00','6667 Dark Rd','A-258 ','Tu/Th',10025),('HDNK 1400',1100,'Hand-to-Hand Combat','Hard Knocks','Fisticuffs','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,10,1,'12:00:00','13:15:00','1234 Tough St','N-577 ','Mon/Wed',10026),('ALC 1400',1100,'Elemental Magic','Witchcraft','Alchemy','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,10,1,'13:00:00','14:15:00','1836 Magic St','S-146 ','Tu/Th',10027),('ALC 1300',1107,'Metal Conversion','Witchcraft','Alchemy','Lecture','Online',NULL,NULL,NULL,NULL,NULL,0,30,3,'14:00:00','15:15:00','Blackboard',' -    ','Mon',10028),('ALC 1300',1107,'Metal Conversion','Witchcraft','Alchemy','Lecture','Hybrid',NULL,NULL,NULL,NULL,NULL,0,35,3,'14:45:00','16:00:00','1836 Magic St & Blackboard','S-765 ','Mon',10029),('ALC 1400',1100,'Elemental Magic','Witchcraft','Alchemy','Lecture','Online',NULL,NULL,NULL,NULL,NULL,0,35,4,'12:30:00','13:45:00','Blackboard',' -    ','Mon/Wed',10030),('ALC ',1100,'Elemental Magic','Witchcraft','Alchemy','Lecture','Hybrid',NULL,NULL,NULL,NULL,NULL,0,35,4,'14:30:00','15:45:00','Blackboard','A-695 ','Wed',10031),('CS 1411',1101,'Data Structures & Algorithms (C++)','Science & Technology','Computer Science','Lecture','Online','null','Yelena','Faris','Plains','null',0,30,4,'12:00:00','13:15:00','Blackboard',' -    ','Tu/Th',10032),('CS 1410',1110,'Intro to Computer Science (C++)','Science & Technology','Computer Science','Lecture','Face-to-Face',NULL,NULL,NULL,NULL,NULL,0,25,4,'13:30:00','14:45:00','4567 Tech Ln','S-1300','Tu/Th',10033),('CS 1410',1110,'Intro to Computer Science (C++)','Science & Technology','Computer Science','Lecture','Online',NULL,NULL,NULL,NULL,NULL,0,25,4,'12:30:00','13:45:00','Blackboard',' -    ','Mon/Wed',10034),('CS 1420',1102,'Intro to Computer Science (Python)','Science & Technology','Computer Science','Lecture','Online',NULL,NULL,NULL,NULL,NULL,0,30,4,'11:30:00','12:45:00','Blackboard',' -    ','Tu/Th',10036),('CS 1430',1105,'Intro to Computer Science (Java)','Science & Technology','Computer Science','Lecture','Hybrid',NULL,NULL,NULL,NULL,NULL,0,25,4,'12:00:00','13:15:00','4567 Tech Ln & Blackboard','A-448 ','Mon',10037),('DMN 1400',1100,'Necromancy','Daemons','Necromancy','Lecture','Hybrid',NULL,NULL,NULL,NULL,NULL,0,20,4,'13:15:00','14:30:00','6667 Dark Rd & Blackboard','N-355 ','Mon',10038),('SMN 1400',1100,'Necromancy','Daemons','Necromancy','Lecture','Online',NULL,NULL,NULL,NULL,NULL,0,20,4,'12:00:00','13:15:00','Blackboard',' -    ','Tu/Th',10039),('HDNK 1400',1111,'Hand-to-Hand Combat','Hard Knocks','Fisticuffs','Lecture','Online',NULL,NULL,NULL,NULL,NULL,0,30,4,'13:45:00','15:00:00','Blackboard',' -    ','Mon/Wed',10040),('HDNK 1400',1111,'Hand-to-Hand Combat','Hard Knocks','Fisticuffs','Lecture','Hybrid',NULL,NULL,NULL,NULL,NULL,0,30,4,'12:00:00','13:15:00','1234 Tough St & Blackboard','N-1146','Wed',10041);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-21 16:06:23
