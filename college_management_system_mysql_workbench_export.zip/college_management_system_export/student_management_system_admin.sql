-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: student_management_system
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `prefix` varchar(9) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s prefix (if any)',
  `fName` varchar(20) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s first name',
  `mName` varchar(20) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s middle name',
  `lName` varchar(20) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s last name',
  `suffix` varchar(6) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s suffix (if any)',
  `DOB` date DEFAULT NULL COMMENT 'The admin''s birthdate',
  `gender` char(1) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s gender',
  `ethnicity` varchar(41) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s ethnicity',
  `email` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s email',
  `uniEmail` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s university email',
  `password` varchar(30) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s password',
  `adminNo` tinyint(1) NOT NULL AUTO_INCREMENT COMMENT 'The admin''s ID number',
  `telNo` varchar(14) COLLATE ascii_bin DEFAULT NULL COMMENT 'The admin''s telephone number',
  `username` varchar(30) COLLATE ascii_bin NOT NULL COMMENT 'The admin''s username',
  PRIMARY KEY (`username`),
  UNIQUE KEY `admincol_UNIQUE` (`username`),
  UNIQUE KEY `adminNo_UNIQUE` (`adminNo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('Ms.','Maria','Driver','Villalobos','null','1983-12-26','F','Hispanic or Latino','driver@hotmail.net','driver@mascot.uni.edu','driver',4,'555-266-2481','driver'),('Ms.','Ashley','Maria','Jackson','null','1990-12-31','F','Black or African American','iam4real@gmail.com','iam4real@mascot.uni.edu','outkast',3,'555-286-2647','iam4real'),('Mr.','King','Excalibur','Arthur','I','1987-12-28','M','White','knight@aol.com','knight@mascot.uni.edu','excalibur',2,'555-777-7777','knight'),(NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'placeholder@email.com','placeholder@mascot.uni.edu','admin',1,NULL,'placeholder');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-21 16:06:22
